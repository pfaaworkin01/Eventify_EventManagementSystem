package Window;

public interface  Window {

    void showWindow();
    void askForInput();
    
}
