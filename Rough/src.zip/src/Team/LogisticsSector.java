package Team;
import java.io.Serializable;
import java.util.ArrayList;
public class LogisticsSector extends Sector implements Serializable {
    private static final long serialVersionUID = 1L;
    public LogisticsSector() {
        super("Logistics", new ArrayList<>());
    }
}
