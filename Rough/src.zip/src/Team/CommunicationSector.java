package Team;

import java.io.Serializable;
import java.util.ArrayList;

public class CommunicationSector extends Sector implements Serializable {
    private static final long serialVersionUID = 1L;
    public CommunicationSector() {
        super("Communication", new ArrayList<>());
    }
}
